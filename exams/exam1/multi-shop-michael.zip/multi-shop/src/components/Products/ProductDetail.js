const ProductDetail = (props) => {

    const getProductDataFromId = () => {
        
    };

    return(
        <>

        </>
    );
};

export default ProductDetail;